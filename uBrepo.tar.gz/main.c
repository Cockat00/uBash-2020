#include "library.h"


int main(void){
	for(;;)
	uBash();
	return 0;
}
